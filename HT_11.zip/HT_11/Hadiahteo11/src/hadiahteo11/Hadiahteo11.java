package hadiahteo11;

/**
 *
 * @author Zero
 */
import java.awt.*;
public class Hadiahteo11 extends Panel{

    /**
     * @param args the command line arguments
     */
    Hadiahteo11() {
        setBackground(Color.GRAY);
    }
    
    public void paint(Graphics g){
        // bagian rambut
        g.setColor(Color.YELLOW);
        g.drawOval(164,6,177,250);
        g.fillOval(164,6,177,250);
        // bagian kepala
        g.setColor(Color.WHITE);
        g.drawOval(192,8,120,120);
        g.fillOval(192,8,120,120);
        // bagian poni
        g.setColor(Color.YELLOW);
        g.drawOval(196,7,110,40);
        g.fillOval(196,7,110,40);
        // bagian mata
        g.setColor(Color.BLACK);
        g.drawOval(225,50,8,8);
        g.fillOval(225,50,8,8);
        g.setColor(Color.BLACK);
        g.drawOval(270,50,8,8);
        g.fillOval(270,50,8,8);
        // bagian mulut
        g.setColor(Color.BLACK);
        g.drawArc(243,80,20,20,5,-180);
        // bagian badan
        g.drawLine(100,170,400,170);
        g.drawLine(255,130,255,400);
        g.drawLine(255, 400, 100, 500);
        g.drawLine(255, 400, 400, 500);
    }
    
    public static void main(String[] args) {
        Frame f = new Frame("Testing Graphics Panel");
        Hadiahteo11 gp = new Hadiahteo11();
        f.add(gp);
        f.setSize(600,600);
        f.setVisible(true);
    }
    
}
